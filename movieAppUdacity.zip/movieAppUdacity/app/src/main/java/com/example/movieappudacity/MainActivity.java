package com.example.movieappudacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.example.movieappudacity.Networks.Internet;
import com.example.movieappudacity.Viewmodel.Viewmodel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    RecyclerView movieRecyclerview;
    RecyclerView.Adapter adapter;
    public static Context context;
    Viewmodel viewmodel;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=MainActivity.this;
        movieRecyclerview=findViewById(R.id.movieRecycler);
        progressBar=findViewById(R.id.progressbar);
        progressBar.setVisibility(View.VISIBLE);
        fetchMovies("popular");


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch (id)
        {
            case R.id.mostPopular:
            {

                fetchMovies("popular");

                break;
            }
            case R.id.topRated:
            {
                progressBar.setVisibility(View.VISIBLE);
                fetchMovies("top_rated");
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    public void fetchMovies(String query)
    {
        Internet internet=new Internet();
        if (!internet.checkConnection())
        {
            Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();
            return;
        }
        movieRecyclerview.setItemAnimator(null);
       // movieRecyclerview.setLayoutManager(new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL));
        movieRecyclerview.setLayoutManager(new GridLayoutManager(MainActivity.this,2));
        movieRecyclerview.setHasFixedSize(true);
        viewmodel= ViewModelProviders.of(this).get(Viewmodel.class);
        viewmodel.setQuery(query);
        viewmodel.getMutableLiveData().observe(this, new Observer<ArrayList<Model>>() {
            @Override
            public void onChanged(ArrayList<Model> models)
            {
             //   arrayList.clear();
                Model model=models.get(1);
                Log.d("dataFromRepo",""+models.get(1)+"/"+model.getOriginalTitle());
                if (models.size()==0)
                {
                    Toast.makeText(getApplicationContext(),"No data found",Toast.LENGTH_SHORT).show();
                    return;
                }

                adapter=new Adapter(getApplicationContext(),models);
                movieRecyclerview.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);


            }

        });

    }
}
