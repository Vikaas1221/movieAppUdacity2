package com.example.movieappudacity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity
{
    ImageView poster;
    TextView Movietitle,MovieRelaseDate,MovieRating,MovieOverview;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        poster=findViewById(R.id.movieImage);
        Movietitle=findViewById(R.id.originalName);
        MovieRelaseDate=findViewById(R.id.dateOfRelase);
        MovieRating=findViewById(R.id.userRating);
        MovieOverview=findViewById(R.id.overview);
        Bundle bundle=getIntent().getExtras();
        String url="https://image.tmdb.org/t/p/w500";
        String title=bundle.getString("title");
        String image=bundle.getString("image");
        String releasedate=bundle.getString("releaseDate");
        String rating=bundle.getString("userrating");
        String overview=bundle.getString("overview");
        Picasso.get().load(url+image).into(poster);
        Movietitle.setText(title);
        MovieRelaseDate.setText(releasedate);
        MovieRating.setText(rating+"/10");
        MovieOverview.setText(overview);

    }
}
