package com.example.movieappudacity.Viewmodel;

import android.content.Context;
import android.graphics.LinearGradient;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.example.movieappudacity.Model;
import com.example.movieappudacity.Repositry.MovieRepositry;

import java.util.ArrayList;

public class Viewmodel extends ViewModel
{
    LiveData<ArrayList<Model>> mutableLiveData;
    MutableLiveData<ArrayList<Model>> mutableLiveDataTop_Rated;
    MutableLiveData<String> queryMutable=new MutableLiveData<>();
    MovieRepositry repositry=null;
    public Viewmodel()
    {
        repositry=new MovieRepositry();
    }
    public void setQuery(String query)
    {
        queryMutable.setValue(query);
    }


    public LiveData<ArrayList<Model>> getMutableLiveData()
    {
        Log.d("uytr","int viewmodel");
        if (mutableLiveData==null)
        {
          //  Transformations.map(queryMutable,input -> repositry.getAllMovies(queryMutable.getValue()));
            mutableLiveData= Transformations.switchMap(queryMutable,input->repositry.getAllMovies(queryMutable.getValue()));
        }
        return mutableLiveData;
    }

}
